import React from 'react'

export default React.createClass({
  render() {
    return <div>Hello, React Router!</div>
  }
})
